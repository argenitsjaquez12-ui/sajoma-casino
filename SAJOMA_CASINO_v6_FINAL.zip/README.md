# SAJOMA CASINO v6

Luxury black-and-gold virtual entertainment casino app built with Flutter.

## Included
- English as the default language.
- Multilingual selector: English, Spanish, Portuguese, French, German, Italian, Chinese, Japanese, Korean, Arabic, Russian and Hindi.
- Black/gold luxury visual identity throughout the games.
- Slots, Roulette, Blackjack and virtual Poker duel.
- Daily virtual bonus, XP, levels, missions and virtual weekly tournament concept.
- Player profile and local history.
- Local persistence with SharedPreferences.
- Virtual coins only. No real-money deposits, withdrawals or betting.

## Build

This repository can be built with Flutter. For GitHub Pages, use a GitHub Actions workflow that runs `flutter create --platforms=web .` before `flutter build web --release --base-href /sajoma-casino/`.
