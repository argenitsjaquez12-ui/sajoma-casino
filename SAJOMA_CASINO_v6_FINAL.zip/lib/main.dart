import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const gold = Color(0xFFD4AF37);
const gold2 = Color(0xFFF4D56A);
const bg = Color(0xFF070707);
const panel = Color(0xFF12100B);

void main() => runApp(const SajomaApp());

class SajomaApp extends StatelessWidget {
  const SajomaApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SAJOMA CASINO',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
        useMaterial3: true,
        cardTheme: const CardThemeData(color: panel, margin: EdgeInsets.zero),
      ),
      home: const Splash(),
    );
  }
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Casino()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.workspace_premium, size: 105, color: gold),
            SizedBox(height: 18),
            Text('SAJOMA CASINO', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: gold, letterSpacing: 2)),
            SizedBox(height: 8),
            Text('PLAY  •  WIN  •  ENJOY', style: TextStyle(color: Colors.white70, letterSpacing: 3)),
          ],
        ),
      ),
    );
  }
}

class Casino extends StatefulWidget {
  const Casino({super.key});
  @override
  State<Casino> createState() => _CasinoState();
}

class _CasinoState extends State<Casino> {
  int balance = 125680;
  int tab = 0;
  int level = 1;
  int xp = 0;
  int wins = 0;
  int played = 0;
  String playerName = 'Player';
  String lang = 'en';
  bool bonusClaimed = false;
  List<Map<String, dynamic>> history = [];
  final Random rng = Random();

  final Map<String, Map<String, String>> tr = {
    'en': {
      'home': 'Home', 'games': 'Games', 'history': 'History', 'missions': 'Missions', 'profile': 'Profile',
      'welcome': 'Welcome', 'virtualBalance': 'VIRTUAL BALANCE', 'dailyBonus': 'Daily Bonus', 'claim': 'CLAIM',
      'gamesTitle': 'GAMES', 'slots': 'Slots', 'roulette': 'Roulette', 'blackjack': 'Blackjack', 'poker': 'Poker',
      'slotsSub': 'Win up to 1,000', 'rouletteSub': 'Special reward on 7', 'blackjackSub': 'Beat the house', 'pokerSub': 'Virtual duel',
      'level': 'Level', 'xp': 'XP', 'play': 'PLAY', 'spin': 'SPIN', 'balance': 'Balance', 'wins': 'Wins',
      'missionsTitle': 'MISSIONS & TOURNAMENT', 'missionsSub': 'Complete goals to earn virtual coins and XP.',
      'missionBonus': 'Daily bonus', 'missionBonusSub': 'Claim today\'s bonus', 'missionPlay': 'Active player', 'missionPlaySub': 'Play 5 games',
      'missionWin': 'First victory', 'missionWinSub': 'Win one game', 'weekly': 'Weekly virtual tournament', 'weeklySub': 'XP ranking • No real money',
      'profileTitle': 'PROFILE', 'changeName': 'Change player name', 'save': 'Save', 'cancel': 'Cancel', 'virtualCoins': 'Virtual coins',
      'experience': 'Experience', 'entertainment': 'Virtual entertainment only', 'language': 'Language', 'defaultEnglish': 'English is the main language',
      'historyEmpty': 'No moves yet.', 'needCoins': 'You need at least 100 coins.', 'alreadyBonus': 'Today\'s bonus was already claimed.',
      'bonusGot': 'Daily bonus: +500 virtual coins!', 'slotTitle': 'SLOTS', 'rouletteTitle': 'ROULETTE', 'blackjackTitle': 'BLACKJACK', 'pokerTitle': 'POKER',
      'spin100': 'SPIN • 100', 'play100': 'PLAY • 100', 'result': 'Result', 'close': 'Close',
      'languageList': 'Select language', 'searchLanguages': 'Languages',
    },
    'es': {'home':'Inicio','games':'Juegos','history':'Historial','missions':'Misiones','profile':'Perfil','welcome':'Bienvenido','virtualBalance':'SALDO VIRTUAL','dailyBonus':'Bono diario','claim':'RECLAMAR','gamesTitle':'JUEGOS','slots':'Tragamonedas','roulette':'Ruleta','blackjack':'Blackjack','poker':'Póker','slotsSub':'Premio hasta 1,000','rouletteSub':'Premio especial en 7','blackjackSub':'Contra la casa','pokerSub':'Duelo virtual','level':'Nivel','xp':'XP','play':'JUGAR','spin':'GIRAR','balance':'Saldo','wins':'Victorias','missionsTitle':'MISIONES Y TORNEO','missionsSub':'Completa objetivos para ganar monedas virtuales y XP.','missionBonus':'Bono diario','missionBonusSub':'Reclama el bono de hoy','missionPlay':'Jugador activo','missionPlaySub':'Juega 5 partidas','missionWin':'Primera victoria','missionWinSub':'Gana una partida','weekly':'Torneo virtual semanal','weeklySub':'Clasificación por XP • Sin dinero real','profileTitle':'PERFIL','changeName':'Cambiar nombre','save':'Guardar','cancel':'Cancelar','virtualCoins':'Monedas virtuales','experience':'Experiencia','entertainment':'Solo entretenimiento virtual','language':'Idioma','defaultEnglish':'Inglés es el idioma principal','historyEmpty':'Todavía no hay movimientos.','needCoins':'Necesitas al menos 100 monedas.','alreadyBonus':'El bono de hoy ya fue reclamado.','bonusGot':'¡Bono diario: +500 monedas virtuales!','slotTitle':'TRAGAMONEDAS','rouletteTitle':'RULETA','blackjackTitle':'BLACKJACK','pokerTitle':'PÓKER','spin100':'GIRAR • 100','play100':'JUGAR • 100','result':'Resultado','close':'Cerrar','languageList':'Selecciona idioma','searchLanguages':'Idiomas'},
    'pt': {'home':'Início','games':'Jogos','history':'Histórico','missions':'Missões','profile':'Perfil','welcome':'Bem-vindo','virtualBalance':'SALDO VIRTUAL','dailyBonus':'Bônus diário','claim':'RESGATAR','gamesTitle':'JOGOS','slots':'Caça-níqueis','roulette':'Roleta','blackjack':'Blackjack','poker':'Pôquer','slotsSub':'Prêmio de até 1.000','rouletteSub':'Prêmio especial no 7','blackjackSub':'Contra a casa','pokerSub':'Duelo virtual','level':'Nível','xp':'XP','play':'JOGAR','spin':'GIRAR','balance':'Saldo','wins':'Vitórias','missionsTitle':'MISSÕES E TORNEIO','missionsSub':'Complete objetivos para ganhar moedas virtuais e XP.','missionBonus':'Bônus diário','missionBonusSub':'Resgate o bônus de hoje','missionPlay':'Jogador ativo','missionPlaySub':'Jogue 5 partidas','missionWin':'Primeira vitória','missionWinSub':'Ganhe uma partida','weekly':'Torneio virtual semanal','weeklySub':'Ranking de XP • Sem dinheiro real','profileTitle':'PERFIL','changeName':'Alterar nome','save':'Salvar','cancel':'Cancelar','virtualCoins':'Moedas virtuais','experience':'Experiência','entertainment':'Somente entretenimento virtual','language':'Idioma','defaultEnglish':'Inglês é o idioma principal','historyEmpty':'Nenhum movimento ainda.','needCoins':'Você precisa de pelo menos 100 moedas.','alreadyBonus':'O bônus de hoje já foi resgatado.','bonusGot':'Bônus diário: +500 moedas virtuais!','slotTitle':'CAÇA-NÍQUEIS','rouletteTitle':'ROLETA','blackjackTitle':'BLACKJACK','pokerTitle':'PÔQUER','spin100':'GIRAR • 100','play100':'JOGAR • 100','result':'Resultado','close':'Fechar','languageList':'Selecionar idioma','searchLanguages':'Idiomas'},
    'fr': {'home':'Accueil','games':'Jeux','history':'Historique','missions':'Missions','profile':'Profil','welcome':'Bienvenue','virtualBalance':'SOLDE VIRTUEL','dailyBonus':'Bonus quotidien','claim':'RÉCLAMER','gamesTitle':'JEUX','slots':'Machines à sous','roulette':'Roulette','blackjack':'Blackjack','poker':'Poker','slotsSub':'Jusqu’à 1 000','rouletteSub':'Récompense spéciale au 7','blackjackSub':'Contre la maison','pokerSub':'Duel virtuel','level':'Niveau','xp':'XP','play':'JOUER','spin':'TOURNER','balance':'Solde','wins':'Victoires','missionsTitle':'MISSIONS ET TOURNOI','missionsSub':'Atteignez les objectifs pour gagner des pièces virtuelles et de l’XP.','missionBonus':'Bonus quotidien','missionBonusSub':'Réclamer le bonus du jour','missionPlay':'Joueur actif','missionPlaySub':'Jouer 5 parties','missionWin':'Première victoire','missionWinSub':'Gagner une partie','weekly':'Tournoi virtuel hebdomadaire','weeklySub':'Classement XP • Sans argent réel','profileTitle':'PROFIL','changeName':'Changer le nom','save':'Enregistrer','cancel':'Annuler','virtualCoins':'Pièces virtuelles','experience':'Expérience','entertainment':'Divertissement virtuel uniquement','language':'Langue','defaultEnglish':'Anglais est la langue principale','historyEmpty':'Aucun mouvement.','needCoins':'Il faut au moins 100 pièces.','alreadyBonus':'Le bonus du jour est déjà réclamé.','bonusGot':'Bonus quotidien : +500 pièces virtuelles !','slotTitle':'MACHINES À SOUS','rouletteTitle':'ROULETTE','blackjackTitle':'BLACKJACK','pokerTitle':'POKER','spin100':'TOURNER • 100','play100':'JOUER • 100','result':'Résultat','close':'Fermer','languageList':'Choisir la langue','searchLanguages':'Langues'},
    'de': {'home':'Start','games':'Spiele','history':'Verlauf','missions':'Missionen','profile':'Profil','welcome':'Willkommen','virtualBalance':'VIRTUELLES GUTHABEN','dailyBonus':'Tagesbonus','claim':'HOLEN','gamesTitle':'SPIELE','slots':'Spielautomaten','roulette':'Roulette','blackjack':'Blackjack','poker':'Poker','slotsSub':'Bis zu 1.000 Gewinn','rouletteSub':'Sondergewinn bei 7','blackjackSub':'Gegen das Haus','pokerSub':'Virtuelles Duell','level':'Level','xp':'XP','play':'SPIELEN','spin':'DREHEN','balance':'Guthaben','wins':'Siege','missionsTitle':'MISSIONEN & TURNIER','missionsSub':'Ziele abschließen und virtuelle Münzen und XP verdienen.','missionBonus':'Tagesbonus','missionBonusSub':'Heutigen Bonus holen','missionPlay':'Aktiver Spieler','missionPlaySub':'5 Spiele spielen','missionWin':'Erster Sieg','missionWinSub':'Ein Spiel gewinnen','weekly':'Virtuelles Wochenturnier','weeklySub':'XP-Rangliste • Kein echtes Geld','profileTitle':'PROFIL','changeName':'Spielername ändern','save':'Speichern','cancel':'Abbrechen','virtualCoins':'Virtuelle Münzen','experience':'Erfahrung','entertainment':'Nur virtuelle Unterhaltung','language':'Sprache','defaultEnglish':'Englisch ist die Hauptsprache','historyEmpty':'Noch keine Aktivitäten.','needCoins':'Mindestens 100 Münzen erforderlich.','alreadyBonus':'Tagesbonus bereits abgeholt.','bonusGot':'Tagesbonus: +500 virtuelle Münzen!','slotTitle':'SPIELAUTOMATEN','rouletteTitle':'ROULETTE','blackjackTitle':'BLACKJACK','pokerTitle':'POKER','spin100':'DREHEN • 100','play100':'SPIELEN • 100','result':'Ergebnis','close':'Schließen','languageList':'Sprache auswählen','searchLanguages':'Sprachen'},
  };

  final Map<String, String> languages = const {
    'en':'English','es':'Español','pt':'Português','fr':'Français','de':'Deutsch','it':'Italiano','zh':'中文','ja':'日本語','ko':'한국어','ar':'العربية','ru':'Русский','hi':'हिन्दी',
  };

  String t(String key) => tr[lang]?[key] ?? tr['en']![key] ?? key;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final saved = p.getString('history');
    if (!mounted) return;
    setState(() {
      balance = p.getInt('balance') ?? 125680;
      playerName = p.getString('name') ?? 'Player';
      lang = p.getString('lang') ?? 'en';
      bonusClaimed = p.getBool('bonus') ?? false;
      level = p.getInt('level') ?? 1;
      xp = p.getInt('xp') ?? 0;
      wins = p.getInt('wins') ?? 0;
      played = p.getInt('played') ?? 0;
      if (saved != null) history = List<Map<String, dynamic>>.from(jsonDecode(saved));
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('balance', balance);
    await p.setString('name', playerName);
    await p.setString('lang', lang);
    await p.setBool('bonus', bonusClaimed);
    await p.setInt('level', level);
    await p.setInt('xp', xp);
    await p.setInt('wins', wins);
    await p.setInt('played', played);
    await p.setString('history', jsonEncode(history));
  }

  void _move(int delta, String event, {bool win = false}) {
    setState(() {
      balance = max(0, balance + delta);
      played++;
      history.insert(0, {'event': event, 'delta': delta, 'time': DateTime.now().toIso8601String()});
      if (history.length > 100) history.removeLast();
      xp += win ? 30 : 10;
      if (win) wins++;
      if (xp >= 100) { level++; xp -= 100; }
    });
    _save();
  }

  void _snack(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));

  void _claimBonus() {
    if (bonusClaimed) { _snack(t('alreadyBonus')); return; }
    setState(() => bonusClaimed = true);
    _move(500, 'Daily bonus +500');
    _snack(t('bonusGot'));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [_home(), _games(), _history(), _missions(), _profile()];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B0A07),
        title: const Text('SAJOMA CASINO', style: TextStyle(color: gold, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
        actions: [
          IconButton(onPressed: _languagePicker, icon: const Icon(Icons.language, color: gold)),
          Padding(padding: const EdgeInsets.only(right: 12), child: Center(child: Text('$balance', style: const TextStyle(color: gold, fontWeight: FontWeight.w800)))),
        ],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: t('home')),
          NavigationDestination(icon: const Icon(Icons.casino_outlined), selectedIcon: const Icon(Icons.casino), label: t('games')),
          NavigationDestination(icon: const Icon(Icons.history), label: t('history')),
          NavigationDestination(icon: const Icon(Icons.emoji_events_outlined), selectedIcon: const Icon(Icons.emoji_events), label: t('missions')),
          NavigationDestination(icon: const Icon(Icons.person_outline), selectedIcon: const Icon(Icons.person), label: t('profile')),
        ],
      ),
    );
  }

  Widget _home() => ListView(padding: const EdgeInsets.all(14), children: [
    _hero(),
    const SizedBox(height: 14),
    _balanceCard(),
    const SizedBox(height: 22),
    Text(t('gamesTitle'), style: const TextStyle(color: gold, fontWeight: FontWeight.w900, letterSpacing: 2, fontSize: 18)),
    const SizedBox(height: 10),
    _gameCard(Icons.casino, t('slots'), t('slotsSub'), const [Color(0xFF3D1C00), Color(0xFFE0A500)], _slots),
    const SizedBox(height: 10),
    _gameCard(Icons.track_changes, t('roulette'), t('rouletteSub'), const [Color(0xFF3B0000), Color(0xFFB68A00)], _roulette),
    const SizedBox(height: 10),
    _gameCard(Icons.style, t('blackjack'), t('blackjackSub'), const [Color(0xFF061C15), Color(0xFFD1A62A)], _blackjack),
    const SizedBox(height: 10),
    _gameCard(Icons.auto_awesome, t('poker'), t('pokerSub'), const [Color(0xFF17002C), Color(0xFFB98A00)], _poker),
  ]);

  Widget _hero() => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      gradient: const LinearGradient(colors: [Color(0xFF17130A), Color(0xFF0A0A0A)]),
      border: Border.all(color: gold.withOpacity(.55)),
      boxShadow: const [BoxShadow(color: Color(0x553D2D00), blurRadius: 20)],
    ),
    child: Row(children: [
      Container(width: 64, height: 64, decoration: const BoxDecoration(shape: BoxShape.circle, color: gold), child: const Icon(Icons.person, size: 38, color: Colors.black)),
      const SizedBox(width: 13),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${t('welcome')}, $playerName', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text('${t('level')} $level • $xp/100 ${t('xp')}', style: const TextStyle(color: Colors.white60)),
        const SizedBox(height: 8),
        ClipRRect(borderRadius: BorderRadius.circular(10), child: LinearProgressIndicator(value: xp / 100, minHeight: 7, color: gold, backgroundColor: Colors.white12)),
      ])),
      IconButton(onPressed: _claimBonus, icon: Icon(Icons.card_giftcard, color: bonusClaimed ? Colors.white24 : gold, size: 31)),
    ]),
  );

  Widget _balanceCard() => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20), border: Border.all(color: gold.withOpacity(.28))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(t('virtualBalance'), style: const TextStyle(color: Colors.white54, letterSpacing: 2)),
      const SizedBox(height: 5),
      Row(children: [const Icon(Icons.monetization_on, color: gold, size: 34), const SizedBox(width: 8), Text('$balance', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: gold))]),
    ]),
  );

  Widget _games() => ListView(padding: const EdgeInsets.all(14), children: [
    Text(t('gamesTitle'), style: const TextStyle(color: gold, fontWeight: FontWeight.w900, fontSize: 24)),
    const SizedBox(height: 12),
    _gameCard(Icons.casino, t('slots'), t('slotsSub'), const [Color(0xFF3D1C00), Color(0xFFE0A500)], _slots, large: true),
    const SizedBox(height: 12),
    _gameCard(Icons.track_changes, t('roulette'), t('rouletteSub'), const [Color(0xFF3B0000), Color(0xFFB68A00)], _roulette, large: true),
    const SizedBox(height: 12),
    _gameCard(Icons.style, t('blackjack'), t('blackjackSub'), const [Color(0xFF061C15), Color(0xFFD1A62A)], _blackjack, large: true),
    const SizedBox(height: 12),
    _gameCard(Icons.auto_awesome, t('poker'), t('pokerSub'), const [Color(0xFF17002C), Color(0xFFB98A00)], _poker, large: true),
  ]);

  Widget _gameCard(IconData icon, String title, String subtitle, List<Color> colors, VoidCallback onTap, {bool large = false}) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(18),
    child: Container(
      height: large ? 145 : 108,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: LinearGradient(colors: colors), border: Border.all(color: gold, width: 1.2)),
      child: Row(children: [
        Container(width: large ? 86 : 65, height: double.infinity, decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: Colors.white, size: large ? 48 : 36)),
        const SizedBox(width: 14),
        Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(fontSize: large ? 21 : 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 10),
          Text('${t('play')}  •  100', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
        ])),
        const Icon(Icons.chevron_right, color: gold2, size: 32),
      ]),
    ),
  );

  Widget _history() => history.isEmpty ? Center(child: Text(t('historyEmpty'))) : ListView.builder(
    padding: const EdgeInsets.all(12), itemCount: history.length, itemBuilder: (_, i) {
      final h = history[i]; final d = (h['delta'] as num).toInt();
      return Card(margin: const EdgeInsets.only(bottom: 8), child: ListTile(
        leading: Icon(d >= 0 ? Icons.arrow_upward : Icons.arrow_downward, color: d >= 0 ? Colors.greenAccent : Colors.redAccent),
        title: Text(h['event']?.toString() ?? ''),
        subtitle: Text((h['time']?.toString() ?? '').replaceFirst('T', ' ').split('.').first),
        trailing: Text('${d >= 0 ? '+' : ''}$d', style: TextStyle(color: d >= 0 ? Colors.greenAccent : Colors.redAccent, fontWeight: FontWeight.w800)),
      ));
    });

  Widget _missions() => ListView(padding: const EdgeInsets.all(14), children: [
    Text(t('missionsTitle'), style: const TextStyle(color: gold, fontWeight: FontWeight.w900, fontSize: 22)),
    const SizedBox(height: 7),
    Text(t('missionsSub'), style: const TextStyle(color: Colors.white60)),
    const SizedBox(height: 14),
    _mission(Icons.card_giftcard, t('missionBonus'), t('missionBonusSub'), bonusClaimed, 500, _claimBonus),
    const SizedBox(height: 8),
    _mission(Icons.casino, t('missionPlay'), '${t('missionPlaySub')} ($played/5)', played >= 5, 750, () => _snack(played >= 5 ? 'Completed' : 'Keep playing')),
    const SizedBox(height: 8),
    _mission(Icons.emoji_events, t('missionWin'), t('missionWinSub'), wins > 0, 1000, () => _snack(wins > 0 ? 'Completed' : 'Keep playing')),
    const SizedBox(height: 18),
    Card(child: ListTile(leading: const Icon(Icons.emoji_events, color: gold), title: Text(t('weekly')), subtitle: Text(t('weeklySub')))),
  ];

  Widget _mission(IconData icon, String title, String sub, bool done, int reward, VoidCallback onTap) => Card(child: ListTile(
    leading: Icon(icon, color: gold, size: 30), title: Text(title), subtitle: Text(done ? '✓ Completed' : sub),
    trailing: done ? const Icon(Icons.check_circle, color: Colors.greenAccent) : FilledButton(onPressed: onTap, child: Text('+$reward')),
  ));

  Widget _profile() => ListView(padding: const EdgeInsets.all(16), children: [
    const SizedBox(height: 12),
    const Center(child: CircleAvatar(radius: 50, backgroundColor: gold, child: Icon(Icons.person, size: 58, color: Colors.black))),
    const SizedBox(height: 12),
    Center(child: Text(playerName, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900))),
    Center(child: Text('${t('level')} $level', style: const TextStyle(color: gold))),
    const SizedBox(height: 20),
    ListTile(leading: const Icon(Icons.monetization_on, color: gold), title: Text(t('virtualCoins')), trailing: Text('$balance')),
    ListTile(leading: const Icon(Icons.emoji_events, color: gold), title: Text(t('wins')), trailing: Text('$wins')),
    ListTile(leading: const Icon(Icons.star, color: gold), title: Text(t('experience')), trailing: Text('$xp / 100')),
    ListTile(leading: const Icon(Icons.edit, color: gold), title: Text(t('changeName')), onTap: _editName),
    ListTile(leading: const Icon(Icons.language, color: gold), title: Text(t('language')), subtitle: Text(languages[lang] ?? languages['en']!), onTap: _languagePicker),
    const SizedBox(height: 25),
    Center(child: Text('SAJOMA CASINO • ${t('entertainment')}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white38))),
  ]);

  void _editName() {
    final controller = TextEditingController(text: playerName);
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Text(t('profileTitle')), content: TextField(controller: controller, decoration: InputDecoration(labelText: t('changeName'))),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(t('cancel'))), FilledButton(onPressed: () { setState(() => playerName = controller.text.trim().isEmpty ? 'Player' : controller.text.trim()); _save(); Navigator.pop(context); }, child: Text(t('save')))],
    ));
  }

  void _languagePicker() {
    showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => SafeArea(child: ListView(
      padding: const EdgeInsets.only(bottom: 12),
      children: [Padding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 10), child: Text(t('languageList'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: gold))),
        ...languages.entries.map((e) => ListTile(leading: Icon(Icons.language, color: e.key == lang ? gold : Colors.white54), title: Text(e.value), trailing: e.key == lang ? const Icon(Icons.check, color: gold) : null, onTap: () { setState(() => lang = e.key); _save(); Navigator.pop(context); }))
      ],
    )));
  }

  bool _needCoins() { if (balance < 100) { _snack(t('needCoins')); return true; } return false; }

  void _slots() {
    if (_needCoins()) return;
    List<String> reels = ['7', 'BAR', 'STAR']; bool busy = false;
    showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (_) => StatefulBuilder(builder: (ctx, setModal) => Padding(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(t('slotTitle'), style: const TextStyle(color: gold, fontSize: 24, fontWeight: FontWeight.w900)), const SizedBox(height: 18),
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: reels.map((x) => Container(width: 82, height: 82, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(14), border: Border.all(color: gold)), child: Text(x, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: gold)))).toList()),
        const SizedBox(height: 20),
        FilledButton(onPressed: busy ? null : () {
          setModal(() => busy = true);
          Future.delayed(const Duration(milliseconds: 450), () {
            final a = ['7', 'BAR', 'STAR', 'GEM', 'BELL']..shuffle(rng); final out = [a[0], a[1], a[2]];
            final delta = out[0] == out[1] && out[1] == out[2] ? 1000 : (out[0] == out[1] || out[1] == out[2] || out[0] == out[2] ? 250 : -100);
            setModal(() { reels = out; busy = false; }); _move(delta, 'Slots ${delta >= 0 ? '+' : ''}$delta', win: delta > 0);
          });
        }, child: Text(t('spin100'))),
      ]),
    )));
  }

  void _roulette() {
    if (_needCoins()) return;
    showDialog(context: context, builder: (_) => AlertDialog(title: Text(t('rouletteTitle')), content: const Text('Virtual roulette. Landing on 7 gives +500 virtual coins.'), actions: [FilledButton(onPressed: () { final n = rng.nextInt(37); final d = n == 7 ? 500 : -100; _move(d, 'Roulette $n ${d >= 0 ? '+' : ''}$d', win: d > 0); Navigator.pop(context); }, child: Text(t('play100')))]));
  }

  void _blackjack() {
    if (_needCoins()) return;
    showDialog(context: context, builder: (_) => AlertDialog(title: Text(t('blackjackTitle')), content: const Text('Quick virtual blackjack. Higher score without going over 21 wins.'), actions: [FilledButton(onPressed: () { final player = 2 + rng.nextInt(20); final house = 2 + rng.nextInt(20); final d = player > 21 ? -100 : (house > 21 || player > house ? 100 : -100); _move(d, 'Blackjack $player/$house ${d >= 0 ? '+' : ''}$d', win: d > 0); Navigator.pop(context); }, child: Text(t('play100')))]));
  }

  void _poker() {
    if (_needCoins()) return;
    showDialog(context: context, builder: (_) => AlertDialog(title: Text(t('pokerTitle')), content: const Text('Quick virtual duel. Higher strength wins.'), actions: [FilledButton(onPressed: () { final a = 1 + rng.nextInt(100); final b = 1 + rng.nextInt(100); final d = a > b ? 150 : -100; _move(d, 'Poker $a vs $b ${d >= 0 ? '+' : ''}$d', win: d > 0); Navigator.pop(context); }, child: Text(t('play100')))]));
  }
}
